-----------------
Tron Light-Cycles
-----------------

This is a clone of the old Tron Light-Cycles arcade games.  It was 
written by me in C++ and uses the nCurses library (pdCurses in the 
Windows implementation) to give me further control of the terminal 
which allows me to read real-time user input and draw colored text 
to the terminal.  One player may play against an AI opponent which 
utilizes a point-based decision making algorithm (at each update of 
the game cycle, the computer player determines which direction to 
move in based on the direction the human player is currently moving 
and the distance between its head and any obstacles (including the 
walls).  For some intense head-to-head multiplayer action, two players 
may face off using the same keyboard!

Controls:

	Movement Player 1: WASD keys
	Movement Player 2: IJKL keys