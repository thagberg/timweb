----------------------------------------
Rigid Body Physics Engine Driver Program
----------------------------------------

This program demonstrates the separating axis theorem collision detection model used
in a rigid-body physics engine I am developing.  This very simple demonstration
program allows you to move around a rectangle and test that the collision detection 
(which was written entirely by myself) works properly.

Controls:

	Movement: Arrow Keys
	Rotation: Q and E rotate the user's rectangle counter-clockwise and clockwise
		  respectively