--------------
Falling Hazard
--------------

This Tetris clone was written by me using C++ and the SDL graphics library.
As a fun bonus while writing this game, I created my own font spritesheet and 
wrote a utility which when given a string will blit together a text image
from cells on the font sprite sheet.  The game features combo point bonuses 
for clearing multiple lines simultaneously.  The next piece to drop into the 
bucket is displayed inside the "cage" at the top of the bucket.  I hope you
ejoy your play!

Controls:

	Movement: Arrow Keys
	Rotation: A and S rotate the active piece counter-clockwise and
		  clockwise respectively