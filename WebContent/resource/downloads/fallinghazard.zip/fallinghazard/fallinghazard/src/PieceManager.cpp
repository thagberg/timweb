// Timothy Hagberg
// Tetris v1.0 27 Aug 2011
// This is the implementation of the PieceManager class
// ----------------------------------------------------

#include "PieceManager.h"


PieceManager::PieceManager(void)
{
	// start with one-second tet drop intervals
	deltaToDropMillis = 1000;
	
	upState = downState = leftState = rightState = false;

}


PieceManager::~PieceManager(void)
{
}

/**
 * init; initialize first Tetromino and load image and resource files
 */
bool PieceManager::init() {
	// seed RNG for selecting tetromino type and color
	srand(static_cast<unsigned int>(time(0)));

	// initialized linesCleared
	linesCleared = 0;

	// load files
	if (!loadFiles()) {
		return false;
	}

	// setup gameBoard
	for (int i = 0; i < 25; i++) {
		for (int j = 0; j < 10; j++) {
			gameBoard[i][j].filled = false;
		}
	}
	
	// initialize first tet
	currentTet = newTet();
	currentTet.setLocation(60, 60);

	// initialize next tet
	nextTet = newTet();
	nextTet.setLocation(60, 0);
		
	// everything initialized properly
	return true;

}

/**
 * loadFiles; loads image and resource files for the PieceManager
 *  returns true if all files load properly
 */
bool PieceManager::loadFiles() {
	// load image files
	red = loadImage("red.png");
	blue = loadImage("blue.png");
	green = loadImage("green.png");
	purple = loadImage("purple.png");
	yellow = loadImage("yellow.png");
	orange = loadImage("orange.png");
	lightGreen = loadImage("lightGreen.png");
	gray = loadImage("gray.png");
	lineDelete = loadImage("lineDelete.png");

	// check if any files did not load properly
	return (red != NULL && blue != NULL && green != NULL &&
			purple != NULL && yellow != NULL && lineDelete != NULL &&
			orange != NULL && lightGreen != NULL && gray != NULL);
}

/**
 * setPieces; create and define pieces for the Tetromino referenced
 */
void PieceManager::setPieces(Tetromino &tet, char type) {
	// create piece objects and set initial values
	Piece piece1, piece2, piece3, piece4;
	piece1.setColor(tet.getColor());
	piece1.setRotation(true);
	piece2.setColor(tet.getColor());
	piece3.setColor(tet.getColor());
	piece4.setColor(tet.getColor());
	piece1.setActive(true);
	piece2.setActive(true);
	piece3.setActive(true);
	piece4.setActive(true);

	
	// create and arrange tet based on type
	switch(type) {
		case 'o':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+45, tet.getY()+30);
			piece3.setLocation(tet.getX()+30, tet.getY()+45);
			piece4.setLocation(tet.getX()+45, tet.getY()+45);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(3, 2, piece2);
			tet.setPiece(2, 3, piece3);
			tet.setPiece(3, 3, piece4);
			break;
		case 'l':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+30, tet.getY()+15);
			piece3.setLocation(tet.getX()+30, tet.getY()+45);
			piece4.setLocation(tet.getX()+45, tet.getY()+45);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(2, 1, piece2);
			tet.setPiece(2, 3, piece3);
			tet.setPiece(3, 3, piece4);
			break;
		case 'j':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+30, tet.getY()+15);
			piece3.setLocation(tet.getX()+30, tet.getY()+45);
			piece4.setLocation(tet.getX()+15, tet.getY()+45);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(2, 1, piece2);
			tet.setPiece(2, 3, piece3);
			tet.setPiece(1, 3, piece4);
			break;
		case 't':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+15, tet.getY()+30);
			piece3.setLocation(tet.getX()+45, tet.getY()+30);
			piece4.setLocation(tet.getX()+30, tet.getY()+45);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(1, 2, piece2);
			tet.setPiece(3, 2, piece3);
			tet.setPiece(2, 3, piece4);
			break;
		case 'i':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+30, tet.getY()+15);
			piece3.setLocation(tet.getX()+30, tet.getY()+45);
			piece4.setLocation(tet.getX()+30, tet.getY()+60);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(2, 1, piece2);
			tet.setPiece(2, 3, piece3);
			tet.setPiece(2, 4, piece4);
			break;
		case 'n':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+30, tet.getY()+45);
			piece3.setLocation(tet.getX()+45, tet.getY()+30);
			piece4.setLocation(tet.getX()+45, tet.getY()+15);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(2, 3, piece2);
			tet.setPiece(3, 2, piece3);
			tet.setPiece(3, 1, piece4);
			break;
		case 'z':
			piece1.setLocation(tet.getX()+30, tet.getY()+30);
			piece2.setLocation(tet.getX()+30, tet.getY()+45);
			piece3.setLocation(tet.getX()+15, tet.getY()+30);
			piece4.setLocation(tet.getX()+15, tet.getY()+15);
			tet.setPiece(2, 2, piece1);
			tet.setPiece(2, 3, piece2);
			tet.setPiece(1, 2, piece3);
			tet.setPiece(1, 1, piece4);
			break;
	}
			
}

/**
 * update; updates state of PieceManager and any of its Tetrominoes and Pieces
 */
int PieceManager::update(SDL_Event *event, int timeMillis, Uint8 *keyStates) {
	int score = 0;
	int cleared = 0;
	
	// collision status of the currently active Tetromino,
	// this is used to determine if a Tetromino has collided and needs to become
	// part of the "Piece blob" at the bottom of the bucket
	char tetCollisionStatus = 0;
	
	char userInput;
	userInput = input(keyStates);

	/////////////////////////////
	// user input and movement //
	/////////////////////////////
	
	if (userInput == ROTATECCW) {
		char collision;
		currentTet.rotateCcw();
		collision = testForCollision();
		if (collision == 1 || collision == 2) {
			currentTet.rotateCw();
		}
	}

	if (userInput == ROTATECW) {
		char collision;
		currentTet.rotateCw();
		collision = testForCollision();
		if (collision == 1|| collision == 2) {
			currentTet.rotateCcw();
		}
	}
	
	if (userInput == LEFT) {
		moveTet(-15, 0);
		lastMoveHor = timeMillis;
	} else if (userInput == RIGHT) {
		moveTet(15, 0);
		lastMoveHor = timeMillis;
	}

	if (userInput == DROP) {
		tetCollisionStatus = moveTet(0, 15);
		lastMoveVert = timeMillis;
	}

	if ((timeMillis - lastMoveHor >= 100)) {
		if (keyStates[SDLK_LEFT] && userInput != LEFT) {
			moveTet(-15, 0);
			lastMoveHor = timeMillis;
		}

		if (keyStates[SDLK_RIGHT] && userInput != RIGHT) {
			moveTet(15, 0);
			lastMoveHor = timeMillis;
		}
	}

	if ((timeMillis - lastMoveVert >= 100)) {
		if (keyStates[SDLK_DOWN] && userInput != DROP) {
			tetCollisionStatus = moveTet(0, 15);
			lastMoveVert = timeMillis;
		}
	}	

	// timer used to determine when to lower the current Tetromino one space
	// deltaToDropMillis will decrease as the level increases, resulting in faster
	// gameplay
	if ((timeMillis - lastDropTimeMillis) >= deltaToDropMillis && !keyStates[SDLK_DOWN]) {
		// move the current Tetromino down one space and get its collision status
		tetCollisionStatus = moveTet(0, 15);
		// reset timer
		lastDropTimeMillis = timeMillis;
	}

	/////////////////////////////////////
	// collision detection and scoring //
	/////////////////////////////////////
		
	// collision status of 2 means the Tetromino has fallen on top of an object
	// and should become part of the "Piece blob"
	if (tetCollisionStatus == 2) {
		// check for filled bucket
		if (currentTet.getY() <= 60) {
			return -1;
		}
		
		// increment score
		score += 100;
		// loop through the pieces of the current Tetromino
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				Piece currentPiece = *currentTet.getPiece(j, i);
				// active pieces are "filled" with color block and are part of the
				// current Tetromino
				if (currentPiece.getActive()) {
					// set these pieces to inactive as they will now be part of the "Piece blob"
					currentPiece.setActive(false);
					// add the piece to the "piece blob"
					SDL_Rect currentRect = currentPiece.getLocation();
					gameBoard[currentRect.y/15][currentRect.x/15-1].pieceHere = currentPiece;
					gameBoard[currentRect.y/15][currentRect.x/15-1].filled = true;
				}
			}
		}
		// get number of lines cleared this update, and increment total number of lines cleared
		linesCleared += cleared = clearLines();
		score += (1000 * cleared) * (double)(1.0 + (double)cleared / 4.0);
		// this Tet is now part of the "Piece blob," so create a new one to begin falling down
		currentTet = nextTet;
		currentTet.setLocation(60-nextTet.getX(), 60-nextTet.getY());
		nextTet = newTet();
		nextTet.setLocation(60, 0);

		if (deltaToDropMillis > 0) {

		}
	}

	return score;
}

/**
 * draw; draw the current Tetromino and "Piece blob" on to the playArea
 */
void PieceManager::draw(SDL_Surface *playArea, SDL_Surface *screen) {
	SDL_Surface *image;

	for (int i = 0; i < 25; i++) {
		for (int j = 0; j < 10; j++) {
			if (gameBoard[i][j].filled) {
				image = whichImage(gameBoard[i][j].pieceHere.getColor());
			
				SDL_Rect tempRect = gameBoard[i][j].pieceHere.getLocation();
				SDL_BlitSurface(image, NULL, playArea, &tempRect);
			}
		}
	}

	// then loop through all the pieces of the current Tetromino and draw those
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			Piece currentPiece = *currentTet.getPiece(j, i);
			if (currentPiece.getActive()) {
				image = whichImage(currentPiece.getColor());

				SDL_Rect tempRect = currentPiece.getLocation();
				SDL_BlitSurface(image, NULL, playArea, &tempRect);
			}
			currentPiece = *nextTet.getPiece(j, i);
			if (currentPiece.getActive()) {
				image = whichImage(currentPiece.getColor());

				SDL_Rect nextRect = currentPiece.getLocation();

				SDL_BlitSurface(image, NULL, playArea, &nextRect);
			}
		}
	}
}

/**
 * moveTet; moves current Tetromino by passed values and returns its
 *  collision status
 */
char PieceManager::moveTet(int x, int y) {
	char collision;
	
	// move the rect representing the Tetromino's location
	currentTet.setLocation(x, y);
	// test for collision in the new location
	collision = testForCollision();

	// has the Tetromino collided vertically with the bottom boundary or another piece?
	if (collision == 2) {
		// move the piece back so it does not overlap whatever it collided with
		currentTet.setLocation(-x, -y);
	
	// has the Tetromino collided horizontally with the side boundaries or another piece?
	} else if (collision == 1) {
		// can't move there, but the Tetromino is still active so just move it back and continue
		currentTet.setLocation(-x, 0);
	}

	// return the collision status
	return collision;
}

/**
 * testForCollision; begin by performing rough collision detection, and then perform
 *  fine-grain detection if collision is possible
 */
char PieceManager::testForCollision() {
	char result = 0;
	
	/// int values to represent x and y coords of this tet for ease-of-access
	int activeTetX, activeTetY;
	activeTetX = currentTet.getX();
	activeTetY = currentTet.getY();

	// check for potential collision of tet with either side
	if (activeTetX <= 15 || activeTetX >= 75) {
		// do fine-grain test for collision
		result = fineCollision();
	}

	// check for potential collision of tet with bottom
	if (activeTetY >= 300) {
		// do fine-grain test for collision and return if result is 2 (meaning tet should become inactive and its pieces stationary
		result = fineCollision();
		if (result == 2) {return result;}
	}

	// check for potential collision of tet with an inactive piece
	for (int i = 0; i < 25; i++) {
		for (int j = 0; j < 10; j++) {
			if (gameBoard[i][j].filled) {
				if (std::abs(activeTetX - (j+1)*15) <= 75 &&
					std::abs(activeTetY - i*15) <= 75) {
						result = fineCollision(&gameBoard[i][j].pieceHere);
						if (result == 2) {return result;}
				}
			}
		}
	}
	
	return result;
}

/**
 * fineCollision; this will actually check for collision on a Piece-by-Piece level
 *  rather than just by the distance between the Tetromino and a collideable object
 */
char PieceManager::fineCollision(Piece *proxPiece) {
	char collision = 0;
	// if proxPiece is not null, we are checking for collision with a Piece
	if (proxPiece != NULL) {
		Piece nearbyPiece = *proxPiece;
		SDL_Rect nPRect = nearbyPiece.getLocation();

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				Piece currentPiece = *currentTet.getPiece(j, i);
				if (currentPiece.getActive()) {
					// retrieve Piece from tet being tested and its rect
					Piece testPiece = *currentTet.getPiece(j, i);
					SDL_Rect tPRect = testPiece.getLocation();

					// check if the test piece has fallen on top of nearby piece
					if (tPRect.y == nPRect.y) {//(nPRect.y - tPRect.y) <= tPRect.h) {
						if (nPRect.x == tPRect.x) {
							return 2;
						}
					// if not, check if test piece is bumping nearby piece horizontally
					} else if (std::abs(tPRect.x - nPRect.x) < tPRect.w && tPRect.y == nPRect.y) {
						collision = 1;
					}
				}
			}
		}
	} 
	// check for collision with play area boundary
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			Piece currentPiece = *currentTet.getPiece(j, i);
			// check if this piece is an empty space
			if (currentPiece.getActive()) {
				// retrieve piece being tested and its rect
				SDL_Rect testRect = currentPiece.getLocation();
				// has this piece touched the bottom of the play area?
				if (testRect.y > testRect.h*24) {
					return 2;
					
				// has this piece touched either side of the play area?
				} else if (testRect.x < testRect.w || testRect.x > testRect.w*10) {
					collision = 1;
				}
			}
		}
	}

	return collision;
}

/**
 * newTet; create and define a new Tetromino
 */
Tetromino PieceManager::newTet() {
	char tetType;
	Tetromino newTet;

	int random = rand() % 7 + 1;

	switch(random) {
		case 1:
			tetType = 'o';
			break;
		case 2:
			tetType = 'l';
			break;
		case 3:
			tetType = 'j';
			break;
		case 4:
			tetType = 't';
			break;
		case 5:
			tetType = 'i';
			break;
		case 6:
			tetType = 'n';
			break;
		case 7:
			tetType = 'z';
			break;
		default:
			tetType = 'i';
			break;
	}

	newTet.setTetType(tetType);
	newTet.setLocation(0, 0);
	setPieces(newTet, tetType);

	return newTet;
}

/**
 * input, determine user input based on Uint8 representing keyboard state
 */
char PieceManager::input(Uint8 *keyStates) {
	// checking upState, downState, leftState, and rightState when a key is pressed
	// is done to make sure if the player is holding a key down, it doesn't move the token
	// on every update, which would be way too fast

	if (keyStates[SDLK_UP] && !upState) {
		upState = true;
		return ROTATECCW;
	} else if (!keyStates[SDLK_UP]){ upState = false;}

	if (keyStates[SDLK_DOWN] && !downState) {
		downState = true;
		return DROP;
	} else if (!keyStates[SDLK_DOWN]){ downState = false;}

	if (keyStates[SDLK_LEFT] && !leftState) {
		leftState = true;
		return LEFT;
	} else if (!keyStates[SDLK_LEFT]){ leftState = false;}

	if (keyStates[SDLK_RIGHT] && !rightState) {
		rightState = true;
		return RIGHT;
	} else if (!keyStates[SDLK_RIGHT]){ rightState = false;}

	if (keyStates[SDLK_a] && !ccwState) {
		ccwState = true;
		return ROTATECCW;
	} else if (!keyStates[SDLK_a]){ ccwState = false;}

	if (keyStates[SDLK_s] && !cwState) {
		cwState = true;
		return ROTATECW;
	} else if (!keyStates[SDLK_s]){ cwState = false;}

	return NEUTRAL;
}

/**
 * clearLines; check for filled lines which need to be cleared
 */
int PieceManager::clearLines() {
	int numLines = 0;
	std::vector<int> lines;
	for (int i = 0; i < 25; i++) {
		bool lineComplete = true;
		for (int j = 0; j < 10; j++) {
			if (!gameBoard[i][j].filled) {
				lineComplete = false;
				break;
			}
		}
		if (lineComplete) {
			numLines++;
			lines.push_back(i);
			clearLine(i);
		}
	}
	return numLines;
}

/**
 * clearLine; clear the line specified by line
 */
void PieceManager::clearLine(int line) {
	for (int i = line; i > 0; i--) {
		for (int j = 0; j < 10; j++) {
			gameBoard[i][j].filled = false;
			if (gameBoard[i-1][j].filled) {
				gameBoard[i][j] = gameBoard[i-1][j];
				gameBoard[i][j].pieceHere.setLocation((j+1)*15, i*15);
			}
		}
	}
}

/**
 * whichImage; return pointer to color block image for the tetromino type passed in
 */
SDL_Surface *PieceManager::whichImage(char tetType) {
	SDL_Surface *image;
	switch (tetType) {
		case 'o':
			image = red;
			break;
		case 'l':
			image = blue;
			break;
		case 'j':
			image = green;
			break;
		case 't':
			image = purple;
			break;
		case 'i':
			image = yellow;
			break;
		case 'n':
			image = orange;
			break;
		case 'z':
			image = lightGreen;
			break;
		default:
			image = yellow;
			break;
	}

	return image;
}

void PieceManager::cleanUp() {
	// free surfaces
	SDL_FreeSurface(red);
	SDL_FreeSurface(blue);
	SDL_FreeSurface(green);
	SDL_FreeSurface(purple);
	SDL_FreeSurface(yellow);
	SDL_FreeSurface(orange);
	SDL_FreeSurface(lightGreen);
	SDL_FreeSurface(gray);
	SDL_FreeSurface(lineDelete);
}