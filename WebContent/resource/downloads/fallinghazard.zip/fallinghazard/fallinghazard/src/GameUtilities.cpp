// Timothy Hagberg
// 27 Aug 2011
// This is the implementation for the GameUtilities.h
// --------------------------------------------------

#include "GameUtilities.h"

/**
 * loadImage; load an image as an SDL_Surface by loading the resource
 *  found at the location specified by the fileName string.
 *  This image will be optimized to use the display format and pixel bit-depth
 *  being used for whatever SDL application calls the function
 */
SDL_Surface *loadImage(std::string fileName) {
	// create a temporary, unoptimized image
	SDL_Surface *temp;

	// create optimized image
	SDL_Surface *optim;

	// load the unoptimized temp image
	temp = IMG_Load(fileName.c_str());

	// if temp image loaded properly
	if (temp != NULL) {
		// optimize image
		optim = SDL_DisplayFormat(temp);

		// free temp image from memory
		SDL_FreeSurface(temp);
	}

	// return optimized image
	return optim;
}

void addTransparency(SDL_Surface *image) {
	// first map colorKey (this is the color that will be made transparent)
	Uint32 colorKey = SDL_MapRGB(image->format, 0, 0xFF, 0xFF);

	// set all pixels of this color to be transparent
	SDL_SetColorKey(image, SDL_SRCCOLORKEY, colorKey);
}

void renderString(SDL_Surface *image, SDL_Surface *font, std::string text) {
	int charWidth;
	SDL_Rect sourceOffset, drawOffset;

	charWidth = font->w / 13;

	sourceOffset.w = drawOffset.w = charWidth;
	sourceOffset.h = drawOffset.h = charWidth;
	drawOffset.y = 0;

	for (int i = 0; i < text.size(); i++) {
		drawOffset.x = i * charWidth;
		if (text[i] >= 48 && text[i] <= 57) {
			sourceOffset.y = 0;
			sourceOffset.x = (text[i] - 48) * charWidth;
		} else if (text[i] >= 65 && text[i] <= 90) {
			sourceOffset.y = ((text[i] - 65) / 13 + 1) * charWidth;
			if (sourceOffset.y == 50) {
				sourceOffset.x = (text[i] - 65 - 13) * charWidth;
			} else {
				sourceOffset.x = (text[i] - 65) * charWidth / (sourceOffset.y / charWidth);
			}
		} else if (text[i] == 32) {
			sourceOffset.y = 0;
			sourceOffset.x = 10 * charWidth;
		}
		SDL_BlitSurface(font, &sourceOffset, image, &drawOffset);
	}
}