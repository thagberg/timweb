// Timothy Hagberg
// 27 Aug 2011
// GameUtilities is a collection of functions which can be used in various
//   2D games which use the SDL library
// -----------------------------------------------------------------------

#include <SDL.h>
#include <SDL_image.h>
#include <string>

SDL_Surface *loadImage(std::string fileName);

void addTransparency(SDL_Surface *image);

void renderString(SDL_Surface *image, SDL_Surface *font, std::string text);