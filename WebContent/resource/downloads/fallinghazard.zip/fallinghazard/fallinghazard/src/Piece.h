// Timothy Hagberg
// Tetris v1.0 27 Aug 2011
// This is a Piece class which represents a block in a Tetromino
// --------------------------------------------------------------

#pragma once
#include <SDL.h>
#include <SDL_image.h>

class Piece
{
public:
	Piece(void);
	Piece(int x, int y, char color);
	~Piece(void);

	void setColor(char color);
	void setLocation(int x, int y);
	void setRotation(bool rotationPiece);
	void setActive(bool active);
	char getColor();
	bool getActive();
	SDL_Rect &getLocation();

private:
	char color;
	bool rotationPiece;
	bool active;
	SDL_Rect location;
};

