// Timothy Hagberg
// Tetris v1.1 8 Sep 2011
// This is a ScoreManager class for a Tetris game
// -----------------------------------------------

#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include "GameUtilities.h"
#include <sstream>

class ScoreManager
{
public:
	ScoreManager(void);
	~ScoreManager(void);

	void update(int score);
	void draw(SDL_Surface *screen);
	bool init();
	void cleanUp();

private:
	int score;
	SDL_Surface *font;
	SDL_Surface *scoreImage;

	void renderScore();
	bool loadFiles();
};

