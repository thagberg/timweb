// Timothy Hagberg
// Tetris v1.0 27 Aug 2011
// This is a manager class for Tetrominoes and Pieces
// --------------------------------------------------

#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <string>
#include "Piece.h"
#include "Tetromino.h"
#include "GameUtilities.h"
#include <cstdlib>
#include <ctime>
#include <vector>

class PieceManager
{
public:
	PieceManager(void);
	~PieceManager(void);

	bool init();
	int update(SDL_Event *event, int timeMillis, Uint8 *keyStates);
	void draw(SDL_Surface *playArea, SDL_Surface *screen);
	void cleanUp();

private:
	enum moveStates{ROTATECW, ROTATECCW, DROP, LEFT, RIGHT, NEUTRAL};
	struct GameSpace {
		Piece pieceHere;
		bool filled;
	};
	
	bool loadFiles();
	void setPieces(Tetromino &t, char type);
	char testForCollision();
	char fineCollision(Piece *proxPiece = NULL);
	char moveTet(int x, int y);
	char input(Uint8 *keyStates);
	Tetromino newTet();
	int clearLines();
	void clearLine(int line);
	SDL_Surface *whichImage(char tetType);

	GameSpace gameBoard[25][10];
	bool cwState;
	bool ccwState;
	bool upState;
	bool downState;
	bool leftState;
	bool rightState;
	int lastDropTimeMillis;
	int deltaToDropMillis;
	int lastMoveVert;
	int lastMoveHor;
	int linesCleared;
	Tetromino currentTet;
	Tetromino nextTet;
	SDL_Surface *red;
	SDL_Surface *blue;
	SDL_Surface *green;
	SDL_Surface *purple;
	SDL_Surface *yellow;
	SDL_Surface *orange;
	SDL_Surface *lightGreen;
	SDL_Surface *gray;
	SDL_Surface *lineDelete;
};

