// Timothy Hagberg
// Tetris v1.0 27 Aug 2011
// This is the implementation for the Piece class
// ----------------------------------------------

#include "Piece.h"


Piece::Piece(void)
{
	location.w = 15;
	location.h = 15;
	rotationPiece = false;
	active = false;
}

Piece::Piece(int x, int y, char color) {
	location.x = x;
	location.y = y;
	location.w = 15;
	location.h = 15;
	this->color = color;
	rotationPiece = false;
	active = false;
}

Piece::~Piece(void)
{
}

void Piece::setColor(char color) {
	this->color = color;
}

void Piece::setRotation(bool rotationPiece) {
	this->rotationPiece = rotationPiece;
}

void Piece::setLocation(int x, int y) {
	location.x = x;
	location.y = y;
}

void Piece::setActive(bool active) {
	this->active = active;
}

bool Piece::getActive() {
	return active;
}

char Piece::getColor() {
	return color;
}

SDL_Rect &Piece::getLocation() {
	return location;
}
