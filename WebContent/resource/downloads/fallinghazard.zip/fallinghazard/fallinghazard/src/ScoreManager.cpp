#include "ScoreManager.h"


ScoreManager::ScoreManager(void)
{
}


ScoreManager::~ScoreManager(void)
{
}


void ScoreManager::update(int score) {
	this->score = score;
}

void ScoreManager::draw(SDL_Surface *screen) {
	// render score as an image
	renderScore();

	SDL_Rect offset;
	offset.x = 25;
	offset.y = 50;
	offset.w = 250;
	offset.h = 25;

	// draw score to screen
	SDL_BlitSurface(scoreImage, NULL, screen, &offset);
}

bool ScoreManager::init() {
	//initialize value of score
	score = 0;

	// prepare surface for scoreImage
	scoreImage = SDL_CreateRGBSurface(SDL_SWSURFACE, 250, 25, 32, NULL, NULL, NULL, NULL);

	// set background of image to be transparent
	addTransparency(scoreImage);

	// load files for manager
	if (!loadFiles()) {
		return false;
	}

	return true;
}

void ScoreManager::renderScore() {
	// create stringstream so we can convert score to a string
	std::stringstream ss;
	std::string scoreString;

	// add score to stream, then return string value of stream
	ss << score;
	scoreString = ss.str();

	// render the string as an image
	renderString(scoreImage, font, scoreString);
}

bool ScoreManager::loadFiles() {
	font = loadImage("pof.png");

	return (font != NULL);
}

void ScoreManager::cleanUp() {
	// free surfaces
	SDL_FreeSurface(font);
	SDL_FreeSurface(scoreImage);
}