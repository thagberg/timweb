// Timothy Hagberg
// Tetris v1.0 27 Aug 2011
// This is the implementation of the Tetromino class
// -------------------------------------------------

#include "Tetromino.h"


Tetromino::Tetromino(void)
{
	location.x = 0;
	location.y = 0;
	location.w = 15*5;
	location.h = 15*5;
}


Tetromino::~Tetromino(void)
{
}

void Tetromino::setTetType(char tetType) {
	this->tetType = tetType;
	this->color = tetType;
}

void Tetromino::setPiece(int x, int y, Piece thisPiece) {
	pieces[y][x] = thisPiece;
}

void Tetromino::setLocation(int x, int y) {
	location.x += x;
	location.y += y;

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			pieces[i][j].getLocation().x += x;
			pieces[i][j].getLocation().y += y;
		}
	}
}

void Tetromino::rotateCcw() {
	if (tetType != 'o') {
		Piece newPieces[5][5];

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				newPieces[j][i] = pieces[i][4-j];
				if (newPieces[j][i].getActive()) {
					newPieces[j][i].setLocation(location.x + (i*15), location.y + (j*15));
				}
			}
		}
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				pieces[i][j] = newPieces[i][j];
			}
		}
	}
}

void Tetromino::rotateCw() {
	if (tetType != 'o') {
		Piece newPieces[5][5];

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				newPieces[j][i] = pieces[4-i][j];
				newPieces[j][i].setLocation(location.x + (i*15), location.y + (j*15));
			}
		}
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				pieces[i][j] = newPieces[i][j];
			}
		}
	}
}

int Tetromino::getX() {
	return location.x;
}

int Tetromino::getY() {
	return location.y;
}

char Tetromino::getColor() {
	return color;
}

Piece *Tetromino::getPiece(int x, int y) {
	return &pieces[y][x];
}
