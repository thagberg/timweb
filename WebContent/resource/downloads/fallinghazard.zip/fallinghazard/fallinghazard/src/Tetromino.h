// Timothy Hagberg
// Tetris v1.0 27 Aug 2011
// This is a Tetromino class which represents the shapes for a Tetris game
// -----------------------------------------------------------------------

#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include "Piece.h"

class Tetromino
{
public:
	Tetromino(void);
	~Tetromino(void);

	void setPiece(int x, int y, Piece thisPiece);
	void setTetType(char tetType);
	void setLocation(int x, int y);
	void rotateCw();
	void rotateCcw();
	int getX();
	int getY();
	char getColor();
	Piece *getPiece(int x, int y);

private:
	Piece pieces[5][5];
	char color;
	char tetType;
	SDL_Rect location;
};

