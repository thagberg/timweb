// Timothy Hagberg
// Tetris v1.1 4 Sep 2011
// This is the entrance and "skeleton" for a Tetris game for Rasmussen College
//
//
// --------------------------------------------------------------------------
// Version History
// ---------------------------------------------------------------------------
// v1.0 27 Aug 2011 - Initial build
// v1.1 4 Sep 2011 - Scoring system implemented, keyboard input implemented
// ---------------------------------------------------------------------------

#include <SDL.h>
#include <SDL_image.h>
#include <string>
#include "PieceManager.h"
#include "ScoreManager.h"
#include "GameUtilities.h"

// screen attributes
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int SCREEN_BPP = 32;

// game attributes
int timeMillis;
int lastTimeMillis;
int score;
Uint8 *keyStates;
PieceManager manager;
ScoreManager sManager;

// surfaces
SDL_Surface *screen;
SDL_Surface *background;
SDL_Surface *bucket;
SDL_Surface *playArea;
SDL_Surface *scoreArea;
SDL_Surface *cage;
SDL_Surface *textImage;
SDL_Surface *font;
SDL_Surface *box;
SDL_Surface *messageArea;
SDL_Surface *message;

// event
SDL_Event event;

// function prototypes
bool init();
bool loadFiles();
void drawPlayArea();
void drawScoreArea();
void drawMessageArea();
void draw();
bool update();
void cleanUp();

int main (int argc, char* args[]) {
	bool quit = false;

	// initialize systems and attributes and exit with error if
	// something does not initialize properly
	if (!init()) {
		return 1;
	}

	// game loop
	while (!quit) {
		// check if close button has been pressed
		if (SDL_PollEvent(&event)) {
			if (event.type == SDL_QUIT) {
				quit = true;
				break;
			}

		}
		// update game state
		quit = update();

		// check if player lost
		if (quit) {
			// prompt player to quit or try again
			drawMessageArea();
			bool pause = true;
			while (pause) {
				// check for event
				if (SDL_PollEvent(&event)) {
					if (event.type == SDL_QUIT) {
						quit = true;
						break;
					} else if (event.type == SDL_KEYDOWN) {
						// if player presses 'y', try again
						if (event.key.keysym.sym == SDLK_y) {
							quit = !init();
							pause = false;
						
						// if player presses 'n', quit
						} else if (event.key.keysym.sym == SDLK_n) {
							pause = false;	
						}
					}
				}
			}
		}
	}
	
	// clean up and free resources
	cleanUp();

	// no issues, close game
	return 0;
}

/**
 * init; initialize SDL services, set up game screens, and load game files and resources
 *  returns true if everything initialized properly, false otherwise
 */
bool init() {
	// set score to 0
	score = 0;
	
	// start SDL services
	if (SDL_Init(SDL_INIT_EVERYTHING) == -1) {
		return false;
	}

	// setup screen
	screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SDL_SWSURFACE);

	// check if screen initialized properly
	if (screen == NULL) {
		return false;
	}

	// set title caption
	SDL_WM_SetCaption("Tetris", NULL);

	// load files
	if (!loadFiles()) {
		return false;
	}

	// add transparency to background of cage image
	addTransparency(cage);

	// add transparency to font image
	addTransparency(font);

	// add transparency to box image
	addTransparency(box);

	// initialize piece manager
	if (!manager.init()) {
		return false;
	}

	// initialize score manager
	if (!sManager.init()) {
		return false;
	}

	// create play area
	playArea = SDL_CreateRGBSurface(SDL_SWSURFACE, 180, 390, SCREEN_BPP, NULL, NULL, NULL, NULL);

	// create score area
	scoreArea = SDL_CreateRGBSurface(SDL_SWSURFACE, 300, 100, SCREEN_BPP, NULL, NULL, NULL, NULL);

	// create placeholder for text image
	textImage = SDL_CreateRGBSurface(SDL_SWSURFACE, 125, 25, SCREEN_BPP, NULL, NULL, NULL, NULL);

	// create message area
	messageArea = SDL_CreateRGBSurface(SDL_SWSURFACE, 500, 100, SCREEN_BPP, NULL, NULL, NULL, NULL);

	// create message
	message = SDL_CreateRGBSurface(SDL_SWSURFACE, 400, 25, SCREEN_BPP, NULL, NULL, NULL, NULL);

	// everything initialized properly
	return true;
}

/**
 * loadFiles; loads the files used for screen format
 *  returns true if all files load properly
 */
bool loadFiles() {
	// load image files
	background = loadImage("background.png");
	bucket = loadImage("bucket.png");
	cage = loadImage("cage.png");
	font = loadImage("pof.png");
	box = loadImage("box.png");

	// if all files loaded properly, return true
	return (background != NULL && bucket != NULL && cage != NULL && font != NULL);
}

/**
 * drawPlayArea; draw the "bucket" and background
 */
void drawPlayArea() {
	SDL_Rect offset;
	for (int i = 0; i < 390; i+=15) {
		for (int j = 0; j < 180; j+= 15) {
			// loop through by 15px increments and draw bucket and bucket background
			offset.x = j;
			offset.y = i;
			if (i < 75) {
				if (j <= 30 || j >= 135) {
					SDL_BlitSurface(bucket, NULL, playArea, &offset);
				}else {
					SDL_BlitSurface(background, NULL, playArea, &offset);
				}
			} else {
				if (j == 0 || j == 165) {
					SDL_BlitSurface(bucket, NULL, playArea, &offset);
				} else if (i == 375) {
					SDL_BlitSurface(bucket, NULL, playArea, &offset);
				} else {
					SDL_BlitSurface(background, NULL, playArea, &offset);
				}
			}
		}
	}
}

void drawScoreArea() {
	SDL_Rect drawOffset;
	SDL_Rect boxOffset;

	boxOffset.w = boxOffset.h = box->h;
	boxOffset.y = 0;

	// first draw the bounding box
	for (int i = 0; i < scoreArea->h; i+=25) {
		for (int j = 0; j < scoreArea->w; j+=25) {
			// establish the offset values
			drawOffset.x = j;
			drawOffset.y = i;
			if (i == 0) {
				if (j == 0) {
					// draw ul box piece
					boxOffset.x = 0;
				} else if (j == scoreArea->w-25) {
					// draw ur box piece
					boxOffset.x = 2*boxOffset.w;
				} else {
					// draw h box piece
					boxOffset.x = 1*boxOffset.w;
				}
			} else if (i == scoreArea->h-25) {
				if (j == 0) {
					// draw bl box piece
					boxOffset.x = 4*boxOffset.w;
				} else if (j == scoreArea->w-25) {
					// draw br box piece
					boxOffset.x = 5*boxOffset.w;
				} else {
					// draw h box piece
					boxOffset.x = 1*boxOffset.w;
				}
			} else if (j == 0 || j == scoreArea->w-25) {
				// draw v box piece
				boxOffset.x = 3*boxOffset.w;
			} else {
				continue;
			}

			// draw the border item
			SDL_BlitSurface(box, &boxOffset, scoreArea, &drawOffset);
		}
	}

	// bounding box is drawn, draw the "Score" text
	std::string text = "SCORE";
	renderString(textImage, font, text);
	drawOffset.x = scoreArea->w / 2 - textImage->w / 2;
	drawOffset.y = 25;
	SDL_BlitSurface(textImage, NULL, scoreArea, &drawOffset);
}

void drawMessageArea() {
	SDL_Rect drawOffset, boxOffset;

	boxOffset.w = boxOffset.h = box->h;
	boxOffset.y = 0;

	// first draw bounding box
	for (int i = 0; i < messageArea->h; i+=25) {
		for (int j = 0; j < messageArea->w; j+=25) {
			// establish the offset values
			drawOffset.x = j;
			drawOffset.y = i;
			if (i == 0) {
				if (j == 0) {
					// draw ul box piece
					boxOffset.x = 0;
				} else if (j == messageArea->w-25) {
					// draw ur box piece
					boxOffset.x = 2*boxOffset.w;
				} else {
					// draw h box piece
					boxOffset.x = 1*boxOffset.w;
				}
			} else if (i == messageArea->h-25) {
				if (j == 0) {
					// draw bl box piece
					boxOffset.x = 4*boxOffset.w;
				} else if (j == messageArea->w-25) {
					// draw br box piece
					boxOffset.x = 5*boxOffset.w;
				} else {
					// draw h box piece
					boxOffset.x = 1*boxOffset.w;
				}
			} else if (j == 0 || j == messageArea->w-25) {
				// draw v box piece
				boxOffset.x = 3*boxOffset.w;
			} else {
				continue;
			}

			// draw the border item
			SDL_BlitSurface(box, &boxOffset, messageArea, &drawOffset);
		}
	}

	// render message string as surface
	renderString(message, font, "TRY AGAIN Y OR N");
	drawOffset.x = messageArea->w / 2 - message->w / 2;
	drawOffset.y = messageArea->h / 2 - message->h / 2;
	SDL_BlitSurface(message, NULL, messageArea, &drawOffset);

	drawOffset.x = screen->w / 2 - messageArea->w / 2;
	drawOffset.y = screen->h / 2 - messageArea->h / 2;
	SDL_BlitSurface(messageArea, NULL, screen, &drawOffset);
	SDL_Flip(screen);
}

/**
 * update; updates game state, calls update functions for manager objects, and calls
 *  draw function
 */
bool update() {
	int tempScore = 0;

	// get current sytem time in milliseconds
	// used to keep game from updating too quickly
	timeMillis = SDL_GetTicks();
	// 33 milliseconds is approximately 1/30 of a second
	// this should keep the game from running faster than 30fps
	if ((timeMillis - lastTimeMillis) >= 33) {
		// get keyboard state
		keyStates = SDL_GetKeyState(NULL);
		// update state of the PieceManager
		tempScore = manager.update(&event, timeMillis, keyStates);
		if (tempScore >= 0) {
			score += tempScore;
		} else {
			return true;
		}
		// update state of scoreManager
		sManager.update(score);
		// draw game screen
		draw();
	}

	return false;
}

/**
 * draw; draw the game screen, bucket, and call any manager object draw functions
 */
void draw() {
	// first clear the screen
	SDL_FillRect(screen, NULL, 0x000000);
	SDL_FillRect(scoreArea, NULL, 0x000000);

	// location for play area to be drawn
	SDL_Rect offset;
	offset.x = 100;
	offset.y = 100;
	
	// render the bucket and background
	drawPlayArea();
	
	// render the score area
	drawScoreArea();

	// call the PieceManager's draw function to draw tetrominoes and blocks
	manager.draw(playArea, screen);

	// draw cage to playArea
	SDL_Rect cageOffset;
	cageOffset.x = 53;
	cageOffset.y = 0;
	SDL_BlitSurface(cage, NULL, playArea, &cageOffset);
	
	// apply the playArea image, which now includes any pieces, to the screen image surface
	SDL_BlitSurface(playArea, NULL, screen, &offset);

	// move the offset rect to the scoreArea section
	offset.x = 400;
	offset.y = 200;

	// draw the score
	sManager.draw(scoreArea);

	// apply the scoreArea image
	SDL_BlitSurface(scoreArea, NULL, screen, &offset);

	// display the screen image which now has the playArea drawn to it
	SDL_Flip(screen);
}

void cleanUp() {
	// clean up managers first
	manager.cleanUp();
	sManager.cleanUp();

	// free surfaces
	SDL_FreeSurface(screen);
	SDL_FreeSurface(background);
	SDL_FreeSurface(bucket);
	SDL_FreeSurface(playArea);
	SDL_FreeSurface(scoreArea);
	SDL_FreeSurface(cage);
	SDL_FreeSurface(textImage);
	SDL_FreeSurface(font);
	SDL_FreeSurface(box);

	// shutdown SDL services
	SDL_Quit();
}